//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //Question i
        String[] strArr = new String[50];

        //Question ii
        String[] strArr;
        strArr[50];

        /Question iii


        //Question iv

        //Question v

        //Question vi
        int[] intArr =  intArr[5], intArr[8];

        //Question vii
        int[][] intArr = new int[5][8];

        //Qustion viii
        int[] intArr;
        intArr[5];
        intArr[8];




    }
}