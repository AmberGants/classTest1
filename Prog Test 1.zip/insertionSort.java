public class insertionSort {
    public static void main(String[] args) {
        int[] insertion = {20, 5, 15, 10, 3, 17, 7};

        int i = 1;
    }
}
