public class bubbleSort {
    public static void main(String[] args) {
        int[] bubbleSort = {10, 5, 20, 25, 29, 27, 22, 12, 18};

        for(int i =1; i < bubbleSort.length; i++){
            if(bubbleSort[i] > bubbleSort[i+1]){
                int temp = bubbleSort[i];
                bubbleSort[i] = bubbleSort[i+1];
                bubbleSort[i] = temp;
            }
        }
        System.out.println();
    }
}
